import logging
import random
from typing import Any, Callable

import dspy
from dspy.adapters.types import History
from dspy.evaluate import Evaluate
from dspy.primitives import Example, Prediction
from dspy.teleprompt.bootstrap_trace import FailedPrediction, TraceData

from gepa import EvaluationBatch, GEPAAdapter
from gepa.proposer.reflective_mutation.base import LanguageModel
from gepa.strategies.instruction_proposal import run_proposal

logger = logging.getLogger(__name__)

# One DSPy trace entry: (predictor, inputs, outputs). outputs may be a FailedPrediction.
_TraceInstance = tuple[Any, dict[str, Any], Any]


def _format_failed_prediction(prediction: FailedPrediction) -> str:
    """Keep malformed completions visible as feedback instead of treating them as mappings."""
    return (
        "Couldn't parse the output as per the expected output format. The model's raw response was:\n"
        f"```\n{prediction.completion_text}\n```\n\n"
    )


def _trajectory_field_grew(key: str, prev: Any, curr: Any) -> bool:
    """True when ReAct's ``trajectory`` input grew as a strict prefix extension.

    Other string fields are not treated as cumulative. Independent calls that append a
    newline section to ``context`` or ``document`` must stay in the trace. History contents
    are not prefix-matched either: an empty or shared-prefix History is a valid independent
    input. History-based ReAct is handled by :func:`_history_records_previous_call`.
    """
    if key.lower() != "trajectory":
        return False
    if not isinstance(prev, str) or not isinstance(curr, str):
        return False
    return prev != curr and curr.startswith(prev)


# Python may share instances of these between unrelated values, so identity says nothing about them.
_SHAREABLE_TYPES = (str, int, float, bool, type(None))


def _history_records_previous_call(prev: _TraceInstance, curr: _TraceInstance) -> bool:
    """True when both calls got the same History object and it holds an output object of ``prev``.

    History-based ReAct (``dspy.ReAct`` from DSPy 3.5, ``dspy.ReActV2`` before that) passes one
    History to every turn and appends each turn's outputs to it, so the trace holds the same
    object, already grown to the final conversation, on every call. Independent calls, even
    with empty or shared-prefix histories, get distinct History objects and are kept.
    """
    if not hasattr(prev[2], "values"):
        return False
    for key, history in prev[1].items():
        if not isinstance(history, History) or curr[1].get(key) is not history:
            continue
        outputs = [v for v in prev[2].values() if type(v) not in _SHAREABLE_TYPES]
        for message in history.messages:
            if isinstance(message, dict) and any(v is out for v in message.values() for out in outputs):
                return True
    return False


def _is_cumulative_repeat(prev: _TraceInstance, curr: _TraceInstance) -> bool:
    """True when curr is the same predictor continuing a ReAct run (a growing trajectory or a shared History)."""
    if prev[0] is not curr[0]:
        return False
    if isinstance(prev[2], FailedPrediction) or isinstance(curr[2], FailedPrediction):
        return False
    prev_inputs, curr_inputs = prev[1], curr[1]
    if not isinstance(prev_inputs, dict) or not isinstance(curr_inputs, dict):
        return False
    for key in prev_inputs.keys() & curr_inputs.keys():
        if _trajectory_field_grew(key, prev_inputs[key], curr_inputs[key]):
            return True
    return _history_records_previous_call(prev, curr)


def _select_trace_instances_for_reflection(trace_instances: list[_TraceInstance]) -> list[_TraceInstance]:
    """Choose which predictor calls to send to the reflection LM.

    Walk the trace in execution order. Consecutive calls to the same predictor are collapsed
    to the last call only when ReAct's ``trajectory`` string grew as a prefix, or when both
    calls share one History object that records the earlier call's outputs. Independent
    map calls, interleaved draft-critique-revise (A, B, A) calls, History inputs (including
    empty, shared-prefix, and growing conversations), and prefix-related ``context`` /
    ``document`` strings are kept.

    A FailedPrediction is never collapsed into a neighbor, so the raw completion stays in
    the trace together with the surrounding calls.
    """
    selected: list[_TraceInstance] = []
    for t in trace_instances:
        if selected and _is_cumulative_repeat(selected[-1], t):
            selected[-1] = t
        else:
            selected.append(t)
    return selected


class DspyAdapter(GEPAAdapter[Example, TraceData, Prediction]):
    def __init__(
        self,
        task_lm: dspy.LM,
        metric_fn: Callable,
        reflection_lm: LanguageModel,
        failure_score=0.0,
        num_threads: int | None = None,
        add_format_failure_as_feedback: bool = False,
        rng: random.Random | None = None,
    ):
        self.task_lm = task_lm
        self.metric_fn = metric_fn
        assert reflection_lm is not None, (
            "DspyAdapter for full-program evolution requires a reflection_lm to be provided"
        )
        self.reflection_lm = reflection_lm
        self.failure_score = failure_score
        self.num_threads = num_threads
        self.add_format_failure_as_feedback = add_format_failure_as_feedback
        self.rng = rng or random.Random(0)

    def build_program(self, candidate: dict[str, str]) -> tuple[dspy.Module, None] | tuple[None, str]:
        candidate_src = candidate["program"]
        context = {}
        o = self.load_dspy_program_from_code(candidate_src, context)
        return o

    def load_dspy_program_from_code(
        self,
        candidate_src: str,
        context: dict,
    ):
        try:
            compile(candidate_src, "<string>", "exec")
        except SyntaxError as e:
            # print(f"Syntax Error in original code {e}")
            # return None
            import traceback

            tb = traceback.format_exc()
            return None, f"Syntax Error in code: {e}\n{tb}"

        try:
            exec(candidate_src, context)  # expose to current namespace
        except Exception as e:
            import traceback

            tb = traceback.format_exc()
            return None, f"Error in executing code: {e}\n{tb}"

        dspy_program = context.get("program")

        if dspy_program is None:
            return (
                None,
                "Your code did not define a `program` object. Please define a `program` object which is an instance of `dspy.Module`, either directly by dspy.Predict or dspy.ChainOfThought, or by instantiating a class that inherits from `dspy.Module`.",
            )
        else:
            if not isinstance(dspy_program, dspy.Module):
                return (
                    None,
                    f"Your code defined a `program` object, but it is an instance of {type(dspy_program)}, not `dspy.Module`. Please define a `program` object which is an instance of `dspy.Module`, either directly by dspy.Predict or dspy.ChainOfThought, or by instantiating a class that inherits from `dspy.Module`.",
                )

        dspy_program.set_lm(self.task_lm)

        return dspy_program, None

    def evaluate(self, batch, candidate, capture_traces=False):
        program, feedback = self.build_program(candidate)

        if program is None:
            return EvaluationBatch(
                outputs=[None for _ in batch], scores=[self.failure_score for _ in batch], trajectories=feedback
            )

        if capture_traces:
            # bootstrap_trace_data-like flow with trace capture
            from dspy.teleprompt.bootstrap_trace import bootstrap_trace_data

            trajs = bootstrap_trace_data(
                program=program,
                dataset=batch,
                metric=self.metric_fn,
                num_threads=self.num_threads,
                raise_on_error=False,
                capture_failed_parses=True,
                failure_score=self.failure_score,
                format_failure_score=self.failure_score,
            )
            # bootstrap_trace_data drops examples whose program raised, but GEPA indexes results by
            # batch position, so keep outputs, scores, and trajectories batch-sized. A dropped example
            # scores failure_score and gets an empty trace, which make_reflective_dataset skips.
            trajectories: list[dict[str, Any]] = [
                {"example": example, "prediction": Prediction(), "trace": [], "example_ind": i, "score": None}
                for i, example in enumerate(batch)
            ]
            outputs: list[Any] = [None] * len(batch)
            for t in trajs:
                trajectories[t["example_ind"]] = t
                outputs[t["example_ind"]] = t["prediction"]
            scores = []
            for t in trajectories:
                score = t.get("score")
                if score is None:
                    scores.append(self.failure_score)
                else:
                    if hasattr(score, "score"):
                        score = score["score"]
                    scores.append(score)
            return EvaluationBatch(outputs=outputs, scores=scores, trajectories=trajectories)
        else:
            evaluator = Evaluate(
                devset=batch,
                metric=self.metric_fn,
                num_threads=self.num_threads,
                return_all_scores=True,
                failure_score=self.failure_score,
                provide_traceback=True,
                max_errors=len(batch) * 100,
            )
            res = evaluator(program)
            outputs = [r[1] for r in res.results]
            scores = [r[2] for r in res.results]
            scores = [s["score"] if hasattr(s, "score") else s for s in scores]
            return EvaluationBatch(outputs=outputs, scores=scores, trajectories=None)

    def make_reflective_dataset(self, candidate, eval_batch, components_to_update):
        """Build reflection examples from captured DSPy traces.

        Each example includes program-level inputs and outputs plus a ``Program Trace``.
        Consecutive ReAct calls (a ``trajectory`` string that grew as a prefix, or one shared
        History that records each turn) are collapsed to the last call of that run.
        Independent repeats, History inputs, and interleaved calls are kept in execution order. A FailedPrediction stays in the trace and is
        not merged into a neighboring call. Failed program outputs also retain the raw
        completion as parse-error feedback.
        """
        proposed_program, _ = self.build_program(candidate)

        assert set(components_to_update) == {"program"}, f"set(components_to_update) = {set(components_to_update)}"

        ret_d: dict[str, list[dict[str, Any]]] = {}

        if isinstance(eval_batch.trajectories, str):
            feedback = eval_batch.trajectories
            return {"program": {"Feedback": feedback}}

        ########
        items: list[dict[str, Any]] = []
        for data in eval_batch.trajectories or []:
            example_data = {}
            trace = data["trace"]
            example = data["example"]
            example_data["Program Inputs"] = {**example.inputs()}
            prediction = data["prediction"]
            example_data["Program Outputs"] = (
                _format_failed_prediction(prediction) if isinstance(prediction, FailedPrediction) else {**prediction}
            )
            module_score = data["score"]

            if hasattr(module_score, "feedback"):
                feedback_text = module_score["feedback"]
            else:
                feedback_text = None

            if hasattr(module_score, "score"):
                module_score = module_score["score"]

            trace_instances = trace

            if len(trace_instances) == 0:
                continue

            trace_instances = _select_trace_instances_for_reflection(trace_instances)

            trace_d = []
            example_data["Program Trace"] = trace_d
            for selected in trace_instances:
                inputs = selected[1]
                outputs = selected[2]

                pred_name = None
                for name, predictor in proposed_program.named_predictors():
                    if predictor.signature.equals(selected[0].signature):
                        pred_name = name
                        break
                assert pred_name is not None, f"Could not find predictor for {selected[0].signature}"

                new_inputs = {}
                new_outputs = {}

                contains_history = False
                history_key_name = None
                for input_key, input_val in inputs.items():
                    if isinstance(input_val, History):
                        contains_history = True
                        assert history_key_name is None
                        history_key_name = input_key

                if contains_history:
                    s = "```json\n"
                    for i, message in enumerate(inputs[history_key_name].messages):
                        s += f"  {i}: {message}\n"
                    s += "```"
                    new_inputs["Context"] = s

                for input_key, input_val in inputs.items():
                    if contains_history and input_key == history_key_name:
                        continue
                    new_inputs[input_key] = str(input_val)

                if isinstance(outputs, FailedPrediction):
                    new_outputs = _format_failed_prediction(outputs)
                else:
                    for output_key, output_val in outputs.items():
                        new_outputs[output_key] = str(output_val)

                d = {"Called Module": pred_name, "Inputs": new_inputs, "Generated Outputs": new_outputs}
                # if isinstance(outputs, FailedPrediction):
                #     adapter = ChatAdapter()
                #     structure_instruction = ""
                #     for dd in adapter.format(module.signature, [], {}):
                #         structure_instruction += dd["role"] + ": " + dd["content"] + "\n"
                #     d["Feedback"] = "Your output failed to parse. Follow this structure:\n" + structure_instruction
                #     # d['score'] = self.failure_score
                # else:
                # assert fb["score"] == module_score, f"Currently, GEPA only supports feedback functions that return the same score as the module's score. However, the module-level score is {module_score} and the feedback score is {fb.score}."
                # d['score'] = fb.score
                trace_d.append(d)

            if feedback_text is not None:
                example_data["Feedback"] = feedback_text

            items.append(example_data)

        if len(items) == 0:
            raise Exception("No valid predictions found for program.")

        ret_d["program"] = items

        ########
        if len(ret_d) == 0:
            raise Exception("No valid predictions found for any module.")

        return ret_d

    def propose_new_texts(
        self,
        candidate: dict[str, str],
        reflective_dataset: dict[str, list[dict[str, Any]]],
        components_to_update: list[str],
    ) -> dict[str, str]:
        from gepa.adapters.dspy_full_program_adapter.dspy_program_proposal_signature import DSPyProgramProposalSignature

        new_texts: dict[str, str] = {}
        for name in components_to_update:
            base_instruction = candidate[name]
            dataset_with_feedback = reflective_dataset[name]
            parsed, _prompt, _raw_output = run_proposal(
                DSPyProgramProposalSignature,
                lm=self.reflection_lm,
                input_dict={"curr_program": base_instruction, "dataset_with_feedback": dataset_with_feedback},
            )
            if parsed.text is None:
                logger.warning(
                    "Skipping malformed full-program reflection output for component %r: %s", name, parsed.error
                )
                continue
            new_texts[name] = parsed.text
        return new_texts
