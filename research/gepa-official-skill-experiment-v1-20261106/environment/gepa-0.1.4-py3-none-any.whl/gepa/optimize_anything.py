"""Public ``optimize_anything`` API.

A call has three parts:

- **What to optimize** — the task fields passed directly to
  :func:`optimize_anything` (``seed_candidate``, ``objective``,
  ``background``, and optional ``dataset`` / ``valset`` / ``test_set``).
- **How to score it** — ``evaluator``, a function returning ``(score, info)``.
- **How to optimize** — :class:`OptimizeAnythingConfig`, which chooses the
  :class:`Engine`, names the run, and sets the budget.

Example:

    from gepa.optimize_anything import OptimizeAnythingConfig, optimize_anything

    def evaluate(candidate: str) -> tuple[float, dict]:
        return run_candidate(candidate), {"diagnostics": "..."}

    result = optimize_anything(
        "initial prompt or program",
        evaluator=evaluate,
        objective="Improve the candidate's score.",
        config=OptimizeAnythingConfig(engine="gepa", max_evals=100),
    )
"""

from __future__ import annotations

import dataclasses
import functools
import threading
import time
import uuid
import warnings
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import Any, cast

# Legacy launcher surface, re-exported so v0.1.x-era code that did
# ``from gepa.optimize_anything import GEPAConfig, ...`` keeps working against
# this module. New code should prefer :class:`OptimizeAnythingConfig`.
from gepa.gepa_launcher import (
    Candidate,
    EngineConfig,
    Evaluator,
    EvaluatorWrapper,
    GEPAConfig,
    GEPAResult,
    Image,
    LogContext,
    MergeConfig,
    OptimizationState,
    RefinerConfig,
    ReflectionConfig,
    SideInfo,
    TrackingConfig,
    get_log_context,
    log,
    make_litellm_lm,
    set_log_context,
)
from gepa.oa.budget import BudgetExhausted, BudgetTracker
from gepa.oa.config import OptimizeAnythingConfig
from gepa.oa.engine import Engine, Result
from gepa.oa.engines import AutoResearchEngine, BestOfNEngine, GepaEngine, MetaHarnessEngine
from gepa.oa.ensemble import (
    optimize_adaptive_sequential,
    optimize_adaptive_sequential_with_server,
    optimize_anything_from_task,
    optimize_anything_with_server,
    optimize_best_of,
    optimize_best_of_with_server,
    optimize_parallel,
    optimize_parallel_with_server,
    optimize_sequential,
    optimize_sequential_with_server,
    optimize_vote,
    optimize_vote_with_server,
)
from gepa.oa.eval_server import EvalServer, _normalize_result, _resolve_id
from gepa.oa.proposers import ClaudeCodeAgentProposer
from gepa.oa.registry import (
    get_engine_cls,
    get_task,
    list_engines,
    list_tasks,
    register_engine,
    register_task,
    register_task_factory,
)
from gepa.oa.task import Task


def optimize_anything(
    seed_candidate: str | Candidate | None = None,
    *,
    evaluator: Callable[..., Any] | None = None,
    batch_evaluator: Callable[..., Any] | None = None,
    dataset: list[Any] | None = None,
    valset: list[Any] | None = None,
    objective: str | None = None,
    background: str | None = None,
    test_set: list[Any] | None = None,
    config: OptimizeAnythingConfig | GEPAConfig | None = None,
) -> GEPAResult:
    """Optimize a text candidate (prompt, code, instructions, ...) against a score.

    The signature mirrors :func:`gepa.gepa_launcher.optimize_anything`
    (``seed_candidate`` / ``evaluator`` / ``batch_evaluator`` / ``dataset`` /
    ``valset`` / ``objective`` / ``background``) so the two entry points share
    one shape; the new API swaps ``config`` for an
    :class:`OptimizeAnythingConfig` and adds ``test_set``.

    Args:
        seed_candidate: The seed to evolve from — either a single text string
            or, for multi-component optimization, a ``{component: text}`` dict
            (:data:`Candidate`) whose components are co-optimized. Dict seeds
            are supported by the ``gepa`` engine; the other engines treat the
            seed as a single text. ``None`` for seedless mode, where the engine
            bootstraps the first candidate from ``objective`` / ``background``.
        evaluator: Scoring function returning ``(score, info)`` — a bare
            ``score`` is also accepted, with ``info`` defaulting to ``{}``. Use
            ``(candidate) -> (score, info)`` for a single task, or
            ``(candidate, example) -> (score, info)`` when dataset/val/test
            examples are provided. ``score`` is a float (higher is better) and
            ``info`` is a free-form dict surfaced to the engine as feedback.
            Optional when ``batch_evaluator`` is provided (at least one is
            required).
        batch_evaluator: Grouped scoring hook (launcher parity): receives ALL
            ``(candidate, example)`` pairs of an evaluation stage in ONE call —
            e.g. to submit a provider batch job or fan out over your own
            infrastructure — and returns one result per pair (``score`` or
            ``(score, info)``). Multi-pair evaluations (minibatch, valset, and
            held-out test passes) prefer it; single-pair evaluations use
            ``evaluator``, or route through the batch function as singleton
            batches when ``evaluator`` is omitted. If its signature accepts an
            ``opt_states`` keyword, the gepa engine forwards the aligned
            per-pair optimization states.
        dataset: Optional training examples used during optimization. Items
            are opaque — any object ``evaluator`` understands. Pairs the
            dataset-shaped ``(candidate, example)`` signature with ``evaluator``.
        valset: Optional validation examples used for candidate selection.
        objective: Short goal statement (e.g. "Maximize sum of circle radii").
            Surfaced verbatim by every engine as the optimization goal.
        background: Long-form context — problem statement, evaluation rules,
            domain notes. Surfaced verbatim by every engine.
        test_set: Optional held-out test examples. When provided, the seed and
            optimized candidates are each scored on it outside the budget — the
            test set never enters the eval server, so engines and agents cannot
            see it. When omitted, test scoring is skipped entirely. Reported
            under ``result.metadata["test_score(s)"]`` (optimized) and
            ``result.metadata["baseline_test_score(s)"]`` (seed).
        config: Engine selection, run ``name``, budgets, output directory, and
            engine-specific options. Defaults to ``OptimizeAnythingConfig()``;
            at least one of ``config.max_evals`` or ``config.max_token_cost``
            must be set. When ``config.name`` is omitted, a name is generated
            from the engine, a short uuid, and a timestamp. A legacy
            :class:`GEPAConfig` is also accepted: the call then runs
            :func:`gepa.gepa_launcher.optimize_anything` directly, exactly as
            in v0.1.4 (no eval server; ``max_metric_calls`` is checked between
            iterations), and ``test_set`` is scored after the run.

    Returns:
        A single :class:`~gepa.core.result.GEPAResult` for every run. The
        universal core is always populated — ``best_candidate``, ``best_score``,
        ``total_evals``, ``eval_log``, ``metadata`` (the lean accessors), plus
        the ``candidates`` / ``best_idx`` / ``val_aggregate_scores`` /
        ``to_dict()`` pool surface. The gepa engine fills the full candidate
        pool and Pareto data; other engines return a single-candidate snapshot
        with the gepa-only fields (``per_val_instance_best_candidates``,
        ``val_aggregate_subscores``, ...) left ``None``/empty. Held-out
        ``test_set`` scores land in ``metadata`` on any engine.

        ``total_evals`` is the eval-server call count (``budget.used``), not
        ``total_metric_calls``. The candidate pool lives on the result
        (``candidates``, ``best_idx``, ...); ``metadata`` no longer nests a
        ``gepa_result`` object. ``to_dict()`` still serializes only the pool
        and GEPA-core fields.

        With a legacy :class:`GEPAConfig` there is no eval server: the
        launcher's result is returned with the same ``eval_log`` and
        ``wall_time`` / ``budget`` / ``total_cost`` / ``engine`` metadata, and
        ``total_evals`` equals the launcher's ``total_metric_calls``.
    """
    if isinstance(config, GEPAConfig):
        # Legacy configs keep v0.1.4 semantics by skipping the eval server (#448).
        return _run_legacy_config(
            seed_candidate,
            evaluator=evaluator,
            batch_evaluator=batch_evaluator,
            dataset=dataset,
            valset=valset,
            objective=objective,
            background=background,
            test_set=test_set,
            config=config,
        )
    if config is None:
        config = OptimizeAnythingConfig()
    elif not isinstance(config, OptimizeAnythingConfig):
        raise TypeError(f"config must be an OptimizeAnythingConfig or GEPAConfig, got {type(config).__name__}")
    if evaluator is None and batch_evaluator is None:
        raise ValueError("Provide evaluator=, batch_evaluator=, or both.")
    if config.max_evals is None and config.max_token_cost is None:
        warnings.warn(
            "Neither config.max_evals nor config.max_token_cost is set; the run is unbounded "
            "and will stop only on the engine's own stop conditions.",
            stacklevel=2,
        )

    result = _optimize_to_result(
        seed_candidate,
        evaluator=evaluator,
        batch_evaluator=batch_evaluator,
        dataset=dataset,
        valset=valset,
        objective=objective,
        background=background,
        test_set=test_set,
        config=config,
    )
    return _to_gepa_result(result, seed_candidate)


def _optimize_to_result(
    seed_candidate: str | Candidate | None,
    *,
    evaluator: Callable[..., Any] | None,
    batch_evaluator: Callable[..., Any] | None,
    dataset: list[Any] | None,
    valset: list[Any] | None,
    objective: str | None,
    background: str | None,
    test_set: list[Any] | None,
    config: OptimizeAnythingConfig,
) -> Result:
    """Run one engine over a freshly-built server and return the mutable core.

    This is the internal Result-producing path shared by the public
    :func:`optimize_anything` (which wraps the result into a
    :class:`~gepa.core.result.GEPAResult`) and by ensemble helpers such as
    :func:`~gepa.oa.ensemble.optimize_anything_from_task` (which thread the
    mutable :class:`Result` across stages).
    """
    task = Task(
        name=config.name or _default_run_name(config.engine),
        seed_candidate=seed_candidate,
        objective=objective or "",
        background=background or "",
        train_set=dataset,
        val_set=valset,
        test_set=test_set,
    )
    engine = _build_engine(config)
    output_dir = _resolve_output_dir(config.output_dir, task=task, engine_name=engine.name)
    # The eval budget caps eval calls only. The proposer-cost cap
    # (config.max_token_cost) is read and enforced by the engine itself.
    budget = BudgetTracker(max_evals=config.max_evals)
    server = EvalServer(
        task,
        evaluator,
        budget,
        batch_evaluate=batch_evaluator,
        max_concurrency=config.max_concurrency,
        output_dir=output_dir,
    )
    return _run_engine(server, engine, owns_server=True)


def _to_gepa_result(result: Result, seed_candidate: Any) -> GEPAResult:
    """Project the mutable engine :class:`Result` onto the unified GEPAResult.

    The gepa engine stashes the full candidate pool under
    ``result.metadata["gepa_result"]``; use it as the rich base. Every other
    engine reports only a best candidate, so synthesize a single-candidate
    snapshot. Either way the universal core (eval log, run metadata, held-out
    test scores, eval-server call count) rides out on the returned result —
    so a generic run returns the maximum information it has, with the gepa-only
    pool fields left at their ``None``/empty defaults. The nested
    ``gepa_result`` is popped from ``metadata``; the returned object *is* the
    pool.
    """
    metadata = dict(result.metadata)
    rich = metadata.pop("gepa_result", None)
    base: GEPAResult = rich if rich is not None else _legacy_result_from(result, seed_candidate)
    return dataclasses.replace(
        base,
        eval_log=list(result.eval_log),
        metadata=metadata,
        eval_server_calls=result.total_evals,
    )


class _EvalRecorder:
    """Pass-through evaluator wrapper that keeps the eval server's ``eval_log``.

    Used on the legacy path, which has no eval server. It records one entry
    per evaluator call in the eval server's format and changes nothing else:
    ``functools.wraps`` keeps the user's signature visible, so the launcher
    introspects (``example`` / ``opt_state`` / ``opt_states``) exactly as it
    would on the unwrapped function.
    """

    def __init__(self) -> None:
        self.log: list[dict[str, Any]] = []
        self.calls = 0
        self.total_cost = 0.0
        self._start = time.time()
        self._lock = threading.Lock()

    def _count_failure(self, n: int) -> None:
        with self._lock:
            self.calls += n

    def _record(self, candidate: Any, result: Any) -> None:
        try:
            score, info = _normalize_result(result)
        except Exception:
            return  # the launcher reports malformed results itself
        cost = float(info.get("cost", 0.0) or 0.0)
        with self._lock:
            self.calls += 1
            self.total_cost += cost
            entry: dict[str, Any] = {
                "eval": self.calls,
                "score": score,
                "candidate_len": len(candidate) if isinstance(candidate, str) else sum(map(len, candidate.values())),
                "wall_time": time.time() - self._start,
                "cumulative_cost": self.total_cost,
            }
            if cost:
                entry["cost"] = cost
            self.log.append(entry)

    def wrap(self, fn: Callable[..., Any] | None) -> Callable[..., Any] | None:
        if fn is None:
            return None

        @functools.wraps(fn)
        def evaluate(candidate: Any, *args: Any, **kwargs: Any) -> Any:
            try:
                result = fn(candidate, *args, **kwargs)
            except Exception:
                self._count_failure(1)
                raise
            self._record(candidate, result)
            return result

        return evaluate

    def wrap_batch(self, fn: Callable[..., Any] | None) -> Callable[..., Any] | None:
        if fn is None:
            return None

        @functools.wraps(fn)
        def evaluate_batch(pairs: Any, *args: Any, **kwargs: Any) -> Any:
            pairs = list(pairs)
            try:
                results = list(fn(pairs, *args, **kwargs))
            except Exception:
                self._count_failure(len(pairs))
                raise
            for (candidate, _example), result in zip(pairs, results, strict=False):
                self._record(candidate, result)
            return results

        return evaluate_batch


def _run_legacy_config(
    seed_candidate: str | Candidate | None,
    *,
    evaluator: Callable[..., Any] | None,
    batch_evaluator: Callable[..., Any] | None,
    dataset: list[Any] | None,
    valset: list[Any] | None,
    objective: str | None,
    background: str | None,
    test_set: list[Any] | None,
    config: GEPAConfig,
) -> GEPAResult:
    """Run a legacy :class:`GEPAConfig` through the launcher, as v0.1.4 did.

    The launcher enforces ``max_metric_calls`` between iterations, so a capped
    run finishes its last iteration instead of discarding it. No eval server,
    budget tracker, or ``outputs/`` tree is involved. The result still gets
    the eval server's bookkeeping: ``eval_log`` and the ``wall_time`` /
    ``budget`` / ``total_cost`` / ``engine`` metadata. ``test_set`` is scored
    afterwards, outside the budget, into the same ``metadata`` keys as the
    eval-server path.
    """
    from gepa.gepa_launcher import optimize_anything as launcher_optimize_anything

    # Build the reflection LM up front (as the launcher would) on a copy of
    # the config, so its cost can be read after the run without writing into
    # the caller's config. A refiner keeps defaulting to the model by name.
    config = dataclasses.replace(
        config,
        reflection=dataclasses.replace(config.reflection),
        refiner=None if config.refiner is None else dataclasses.replace(config.refiner),
    )
    if config.refiner is not None and config.refiner.refiner_lm is None:
        config.refiner.refiner_lm = config.reflection.reflection_lm
    cost_source = GepaEngine._resolve_cost_source(config)

    recorder = _EvalRecorder()
    result = launcher_optimize_anything(
        seed_candidate,
        evaluator=recorder.wrap(evaluator),
        batch_evaluator=recorder.wrap_batch(batch_evaluator),
        dataset=dataset,
        valset=valset,
        objective=objective,
        background=background,
        config=config,
    )
    max_evals = config.engine.max_metric_calls
    budget: dict[str, Any] = {"exhausted": max_evals is not None and recorder.calls >= max_evals}
    if max_evals is not None:
        budget.update(max_evals=max_evals, used=recorder.calls, remaining_evals=max(0, max_evals - recorder.calls))
    reflection_cost = float(getattr(cost_source, "total_cost", 0.0) or 0.0)
    result = dataclasses.replace(result, eval_log=recorder.log)
    result.metadata.update(
        wall_time=time.time() - recorder._start,
        budget=budget,
        adapter_cost=reflection_cost,
        total_cost=recorder.total_cost + reflection_cost,
        progress_log=[],
        engine="gepa",
    )
    if test_set:
        task = Task(name="test", seed_candidate=seed_candidate, test_set=test_set)
        scorer = EvalServer(task, evaluator, BudgetTracker(max_evals=None), batch_evaluate=batch_evaluator)
        try:
            baseline = _score_test(scorer, task, seed_candidate)
            optimized = (
                baseline
                if result.best_candidate == seed_candidate
                else _score_test(scorer, task, result.best_candidate)
            )
        finally:
            scorer.stop()
        if baseline is not None:
            result.metadata["baseline_test_scores"], result.metadata["baseline_test_score"] = baseline
        if optimized is not None:
            result.metadata["test_scores"], result.metadata["test_score"] = optimized
    return result


def _legacy_result_from(result: Result, seed_candidate: Any) -> GEPAResult:
    """Single-candidate :class:`GEPAResult` when there is no candidate pool.

    Used for every non-gepa engine (which reports only a best candidate) and
    for the gepa engine when the eval budget is exhausted before GEPA core
    saved any state (e.g. the budget is smaller than the seed's valset pass).
    Returns a single-candidate snapshot of the best the eval server saw, so the
    unified result still exposes the pool surface (``candidates``, ``best_idx``,
    ``val_aggregate_scores``, ``to_dict()``) with the gepa-only fields empty.
    """
    best = result.best_candidate or seed_candidate
    if isinstance(best, dict):
        candidate, key = best, None
    else:
        candidate, key = {"current_candidate": best or ""}, "current_candidate"
    score = float(result.best_score) if result.best_score is not None else float("-inf")
    return GEPAResult(
        candidates=[candidate],
        parents=[[None]],
        val_aggregate_scores=[score],
        val_subscores=[{}],
        per_val_instance_best_candidates={},
        discovery_eval_counts=[result.total_evals or 0],
        total_metric_calls=result.total_evals,
        _str_candidate_key=key,
    )


def _run_engine(server: EvalServer, engine: Engine, *, owns_server: bool) -> Result:
    """Run ``engine`` and attach shared eval-server metadata to its result.

    The HTTP listener is not started here: engines bind it lazily on their
    first ``server.url`` access, so pure in-process runs never open a
    localhost socket (#448).
    """
    task = server.task

    # Held-out test is scored outside the budget, directly against the seed
    # candidate (baseline) and, after optimization, the best candidate. The
    # test_set is optional — when absent these passes are skipped entirely.
    baseline_test = _score_test(server, task, task.seed_candidate)

    start = time.time()
    try:
        result = engine.run(task, server)
    except BudgetExhausted:
        result = Result(
            # A dict best rides through on the gepa/dict-seed path, matching
            # GepaEngine.run's own ``cast`` at the Result boundary.
            best_candidate=cast(str, server.best_candidate),
            best_score=server.best_score,
        )
    finally:
        if owns_server:
            server.stop()

    result.total_evals = server.budget.used
    result.eval_log = server.eval_log
    result.metadata.setdefault("wall_time", time.time() - start)
    result.metadata["budget"] = server.budget.status()
    adapter_cost = float(result.metadata.get("adapter_cost", 0.0))
    result.metadata["total_cost"] = server.total_cost + adapter_cost
    result.metadata["progress_log"] = server.progress_log
    result.metadata["engine"] = engine.name
    if server.output_dir is not None:
        result.metadata["output_dir"] = str(server.output_dir)

    try:
        engine.process_result(result, server.output_dir)
    except Exception:
        # Engine artifact persistence is best-effort.
        pass

    # Reuse the baseline pass when the engine made no improvement, otherwise
    # score the optimized candidate. Both are optional and skipped without a
    # test_set.
    if result.best_candidate == task.seed_candidate:
        optimized_test = baseline_test
    else:
        optimized_test = _score_test(server, task, result.best_candidate)

    if baseline_test is not None:
        result.metadata["baseline_test_scores"], result.metadata["baseline_test_score"] = baseline_test
    if optimized_test is not None:
        result.metadata["test_scores"], result.metadata["test_score"] = optimized_test

    return result


def _score_test(
    server: EvalServer, task: Task, candidate: str | dict[str, str] | None
) -> tuple[dict[str, float], float] | None:
    """Score ``candidate`` on the held-out ``test_set``, outside the budget.

    Returns ``(per_example_scores, average)`` or ``None`` when there is no
    test_set or no candidate to score. Test examples are evaluated directly
    via ``eval_fn`` — they never touch the eval server's budget or pool.
    """
    if not task.test_set or not candidate:
        return None
    if server.batch_fn is not None:
        # Grouped test pass: the user's batch function gets all pairs in one call.
        try:
            per_example = [score for score, _info in server.batch_fn([(candidate, ex) for ex in task.test_set])]
        except Exception:
            per_example = [0.0] * len(task.test_set)
    else:
        per_example = []
        for ex in task.test_set:
            try:
                per_example.append(server.eval_fn(candidate, ex)[0])
            except Exception:
                per_example.append(0.0)
    scores: dict[str, float] = {}
    for i, (ex, score) in enumerate(zip(task.test_set, per_example, strict=True)):
        eid = _resolve_id(ex, f"test_{i}")
        if eid in scores:
            eid = f"test_{i}"
        scores[eid] = score
    avg = sum(scores.values()) / len(scores) if scores else 0.0
    return scores, avg


def _build_engine(config: OptimizeAnythingConfig) -> Engine:
    """Instantiate ``config.engine`` or return it if it is already an engine."""
    if isinstance(config.engine, str):
        cls = get_engine_cls(config.engine)
        return cls(config)
    if config.engine_config:
        warnings.warn(
            "OptimizeAnythingConfig.engine_config is ignored when OptimizeAnythingConfig.engine is a constructed "
            "Engine instance.",
            stacklevel=3,
        )
    return config.engine


def _default_run_name(engine: str | Engine) -> str:
    """Generate a run name from the engine, a short uuid, and a timestamp."""
    backend = engine if isinstance(engine, str) else getattr(engine, "name", "engine")
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    return f"{backend}-{uuid.uuid4().hex[:8]}-{ts}"


def _resolve_output_dir(output_dir: str | Path | None, *, task: Task, engine_name: str) -> Path:
    """Return an explicit output dir or create the standard timestamped one."""
    if output_dir is not None:
        path = Path(output_dir)
    else:
        ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        path = Path("outputs") / "optimize_anything" / task.name / engine_name / ts
    path.mkdir(parents=True, exist_ok=True)
    return path


__all__ = [
    "AutoResearchEngine",
    "BestOfNEngine",
    "BudgetExhausted",
    "BudgetTracker",
    # Legacy launcher surface (v0.1.x `gepa.optimize_anything` API), re-exported
    # for backward compatibility.
    "Candidate",
    "ClaudeCodeAgentProposer",
    "Engine",
    "EngineConfig",
    "EvalServer",
    "Evaluator",
    "EvaluatorWrapper",
    "GEPAConfig",
    "GEPAResult",
    "GepaEngine",
    "Image",
    "LogContext",
    "MergeConfig",
    "MetaHarnessEngine",
    "OptimizationState",
    "OptimizeAnythingConfig",
    "RefinerConfig",
    "ReflectionConfig",
    "Result",
    "SideInfo",
    "Task",
    "TrackingConfig",
    "get_engine_cls",
    "get_log_context",
    "get_task",
    "list_engines",
    "list_tasks",
    "log",
    "make_litellm_lm",
    "optimize_adaptive_sequential",
    "optimize_adaptive_sequential_with_server",
    "optimize_anything",
    "optimize_anything_with_server",
    "optimize_best_of",
    "optimize_best_of_with_server",
    "optimize_parallel",
    "optimize_parallel_with_server",
    "optimize_sequential",
    "optimize_sequential_with_server",
    "optimize_anything_from_task",
    "optimize_vote",
    "optimize_vote_with_server",
    "register_engine",
    "register_task",
    "register_task_factory",
    "set_log_context",
]


def __getattr__(name: str) -> Any:
    """Permanent compatibility shim for the v0.1.x ``gepa.optimize_anything`` API.

    The commonly-imported launcher names are re-exported explicitly at the top
    of this module. This fallback catches any *other* public symbol a pinned
    v0.1.x caller may still import (e.g. ``EvaluatorWrapper``) and forwards it
    from :mod:`gepa.gepa_launcher`, so old imports keep working unmodified
    instead of hitting a bare ``ImportError``. Truly-unknown names raise
    ``AttributeError`` with a pointer to where the launcher surface now lives.
    """
    if not name.startswith("_"):
        import gepa.gepa_launcher as _launcher

        obj = getattr(_launcher, name, None)
        if obj is not None:
            return obj
    raise AttributeError(
        f"module {__name__!r} has no attribute {name!r}. The legacy launcher surface now lives in 'gepa.gepa_launcher'."
    )
